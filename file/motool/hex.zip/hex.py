def charrep(c):
	m = { # missing 01 and 1c to 1f
		'\0': '\\0',
		'\n': '\\n',
		'\r': '\\r',
		' ': '\\s',
		'\t': '\\t',
	}
	if c in m:
		return m[c]
	return c+' '

def chartohex(c):
	h = hex(ord(c))[2:]
	if len(h) > 1:
		return h
	return '0'+h

def printhex(string):
	hexes = list(map(chartohex, string))
	for i in range(0, len(string), 16): # 1 row at a time
		# A  q
		# 57 AC
		print(' '.join(map(charrep, list(string[i:i+16]))))
		print(' '.join(list(hexes[i:i+16])))

def main():
	print('Hex loaded.')
	while 1:
		command = input('@hex> ')
		action = command.split(' ')[0]
		unaction = ' '.join(command.split(' ')[1:])
		# main
		if action == 'calc':
			printhex(unaction)
		elif action == 'read':
			printhex(open(unaction, 'r').read())
		# leave these at the bottom
		elif action == 'help':
			print('calc help read exit')
		elif action == 'exit':
			break
		else:
			print('unknown command')