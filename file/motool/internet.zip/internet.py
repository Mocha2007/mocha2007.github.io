import os,platform,re,urllib.request # everywhere

version = 'Kaldoêt/1.2'
systeminfo = platform.platform().replace('-',' ')
user_agent = version+' ('+systeminfo+' mocha2007.github.io)'
headers={'User-Agent':user_agent,}

downloads = './downloads/'
home = 'https://mocha2007.github.io/index.html'
location = home
tempfile = 'kaldoet.tmp'
bookmarkfile = './data/bookmarks.tsv'

# build bookmarks
bookmarks = {}
try:
	progdictfile = open(bookmarkfile,'r').read().split('\n')
	for line in progdictfile:
		butt = line.split('\t')
		bookmarks[butt[0]] = butt[1]
except (FileNotFoundError,IndexError):
	pass

# history
history = []
past = []
future = []

# MAKE SURE TO USE [^\0] instead of .!!!!!

def getdomain(url):
	''' get domain url'''
	return re.search(r'^https?:\/.+?(?=\/)',url,flags=re.IGNORECASE).group(0)

def getpagefolder(url):
	''' get everything but the page (ie. domain + directory)'''
	return re.search(r'^https?:\/.+\/',url,flags=re.IGNORECASE).group(0)

def getparentfolder(url):
	''' get parent of url'''
	return re.search(r'^https?:\/.+(?=\/)',url,flags=re.IGNORECASE).group(0)

def bookmark(name,url):
	try:
		progdictfile = open(bookmarkfile,'a').write('\n'+name+'\t'+url)
	except FileNotFoundError:
		progdictfile = open(bookmarkfile,'w+').write(name+'\t'+url)
	bookmarks[name] = url

def deleteinvis(x):
	# comments
	x = re.sub('<!--[^\0]*?-->','',x)
	# head
	x = re.sub(r'<head>[^\0]*?<\/head>','',x,flags=re.IGNORECASE)
	# head stuff
	x = re.sub(r'<!DOCTYPE.+?>','',x,flags=re.IGNORECASE)
	x = re.sub('<((link)|(meta)|(title))[^\0]*?>','',x,flags=re.IGNORECASE)
	x = re.sub('<script.+?script>','',x,flags=re.IGNORECASE)
	x = re.sub('<style.+?style>','',x,flags=re.IGNORECASE)
	# br
	x = re.sub(r'<br\/?>','\n',x,flags=re.IGNORECASE)
	return x

def getmeta(html):
	metas = re.findall(r'<meta.+?>',html,flags=re.IGNORECASE)
	metalist = []
	for meta in metas:
		try:
			ischarset = re.search(r'(?<=charset=").+?(?=")',meta,flags=re.IGNORECASE)
			if ischarset:
				metalist.append(('charset',ischarset.group(0)))
			else:
				name = re.search(r'(?<=name=").+?(?=")',meta,flags=re.IGNORECASE).group(0)
				content = re.search(r'(?<=content=").+?(?=")',meta,flags=re.IGNORECASE).group(0)
				metalist.append((name,content))
		except:
			pass
	return metalist

def gethreffroma(a):
	return re.search(r'(?<=href=")[^\0]*?(?=")',a,flags=re.IGNORECASE).group(0)

def gettextfroma(a):
	return re.search(r'(?<=[^a]>)[^\0]*?(?=</a>)',a,flags=re.IGNORECASE).group(0)

def getaltfromimg(img):
	return re.search(r'(?<=alt=").+?(?=")',img,flags=re.IGNORECASE).group(0)

def getlinks(x):
	links = re.findall(r'<a [^\0]*?a>',x,flags=re.IGNORECASE)
	try:
		linklist = list(zip(map(gettextfroma,links),map(gethreffroma,links)))
	except AttributeError:
		print('No links found.')
		return []
	for i in range(len(linklist)):
		link = linklist[i]
		text = link[0]
		if '<img' in link[0]: # get alts from img tags
			try:
				text = getaltfromimg(link[0])
			except AttributeError:
				text = '(Image with no alt)'
		text = re.sub('<.+?>','',text) # remove all tags
		text = text.replace('\n','') # remove newlines
		print('('+str(i)+') '+text+'\n\t-> '+link[1]+'\n')
	return linklist

def htmltotext(x):
	x = deleteinvis(x)
	x = x.replace('<','\n<') # clarity
	return x

def download(name,to):
	if not os.path.exists(downloads):
		os.makedirs(downloads)
	urllib.request.urlretrieve(name,filename=downloads+to)

def main():
	global location # idk if this is necessary but just in case
	html = ''
	meta = []
	linklink = getlinks(html)
	print(version+' loaded.')
	while 1:
		command = input('@k> ')
		action = command.split(' ')[0].lower()
		args = command.split(' ')[1:]
		unaction = ' '.join(args)
		# preformat
		if action == 'home':
			action = 'go'
			unaction = home
		elif action == 'gobook':
			action = 'go'
			unaction = bookmarks[unaction.lower()]
		elif action == 'golink':
			action = 'go'
			try:
				unaction = linklink[int(unaction)][1]
			except IndexError:
				print('Not in link range - did you forget to generate links with "link"?')
				action = 'help'
		# commands
		if action in ('about','info'):
			print(version)
			print('A text-based explorer for the interwebs.')
		elif action in ('b','bookmark'):
			bookmark(args[0].lower(),' '.join(args[1:]))
		elif action in ('bl','bookmarklist','bookmarks'):
			try:
				for line in open(bookmarkfile,'r').read().split('\n'):
					print(line)
			except:
				print('No bookmarks')
		elif action[:4] == 'disp':
			print(html)
		elif action in ('back','forward','gb','gf','go'):
			# detect relative versus absolute links
			try:
				if action in ('back','gb'):
					unaction = past.pop()
				elif action in ('forward','gf'):
						unaction = future.pop()
				elif unaction[:4] != 'http':
					if unaction[:3] == '../': # trying to make this work for ../blah.html
						targetparent = getpagefolder(location)
						unaction = getparentfolder(targetparent[:-1]) + unaction[3:]
					else:
						unaction = getpagefolder(location) + '/' + unaction
			except IndexError:
				unaction = location
			try:
				download(unaction,tempfile)
				html = open(downloads+tempfile).read()
				html = re.sub('[^ -~]','?',html)
				meta = getmeta(html)
				html = htmltotext(html)
				# history
				if action in ('back','gb'):
					future.append(location)
				elif action in ('forward','gf'):
					past.append(location)
				else:
					history.append(unaction)
					past.append(location)
				# final
				location = unaction
			except Exception as e:
				print('problem travelling to '+unaction+' :\n'+str(e))
		elif action[:4] == 'help':
			print('about=info b=bookmark back=gb bl disp forward=gf go gobook golink help hist=history link meta exit')
		elif action in ('hist','history'):
			for page in history:
				print(page)
		elif action[:4] == 'link':
			linklink = getlinks(html)
		elif action[:4] == 'meta':
			for name,content in meta:
				print(name,'\n\t->',content)
		# leave these at the bottom
		elif action == 'exit':
			break
		else:
			print('unknown command')