import os,platform,re,urllib.request # everywhere

version = 'Kaldoêt/1.0'
systeminfo = platform.platform().replace('-',' ')
user_agent = version+' ('+systeminfo+' mocha2007.github.io)'
headers={'User-Agent':user_agent,}

downloads = '../downloads/'
home = 'https://mocha2007.github.io/index.html'
location = home
tempfile = 'kaldoet.tmp'

# MAKE SURE TO USE [^\0] instead of .!!!!!

def deleteinvis(x):
	# comments
	x = re.sub('<!--[^\0]*?-->','',x)
	# head
	x = re.sub(r'<head>[^\0]*?<\/head>','',x)
	# head stuff
	x = re.sub('<((link)|(meta)|(script)|(style)|(title))[^\0]*?>','',x)
	return x

def gethreffroma(a):
	return re.search(r'(?<=href=")[^\0]*?(?=")',a).group(0)

def gettextfroma(a):
	return re.search(r'(?<=[^a]>)[^\0]*?(?=</a>)',a).group(0)

def getlinks(x):
	links = re.findall(r'<a [^\0]*?a>',x)
	linklist = list(zip(map(gettextfroma,links),map(gethreffroma,links)))
	for i in range(len(linklist)):
		link = linklist[i]
		print('('+str(i)+') '+link[0]+'\t-> '+link[1]+'\n')
	return linklist

def htmltotext(x):
	x = deleteinvis(x)
	x = x.replace('<','\n<') # clarity
	return x

def download(name,to):
	if not os.path.exists(downloads):
		os.makedirs(downloads)
	urllib.request.urlretrieve(name,filename=downloads+to)

def main():
	html = ''
	linklink = getlinks(html)
	print(version+' loaded.')
	while 1:
		command = input('@k> ')
		action = command.split(' ')[0].lower()
		args = command.split(' ')[1:]
		unaction = ' '.join(args)
		# preformat
		if action == 'home':
			action = 'go'
			unaction = home
		elif action == 'golink':
			action = 'go'
			unaction = linklink[int(unaction)][1]
		# commands
		if action in ('about','info'):
			print(version)
			print('A text-based explorer for the interwebs.')
		elif action[:4] == 'disp':
			print(html)
		elif action == 'go':
			try:
				download(unaction,tempfile)
				html = open(downloads+tempfile).read()
				html = re.sub('[^ -~]','?',html)
				html = htmltotext(html)
				location = unaction
			except:
				print('problem travelling to '+unaction)
		elif action[:4] == 'help':
			print('about disp go golink help info link exit')
		elif action[:4] == 'link':
			linklink = getlinks(html)
		# leave these at the bottom
		elif action == 'exit':
			break
		else:
			print('unknown command')