import os,platform,re,urllib.request # everywhere

version = 'Kaldoêt/1.4'
systeminfo = platform.platform().replace('-',' ')
user_agent = version+' ('+systeminfo+' mocha2007.github.io)'
headers={'User-Agent':user_agent,}

downloads = 'downloads/'
home = 'https://mocha2007.github.io/index.html'
location = home
tempfile = 'kaldoet.tmp'
bookmarkfile = 'data/bookmarks.tsv'

# build bookmarks
bookmarks = {}
try:
	progdictfile = open(bookmarkfile,'r').read().split('\n')
	for line in progdictfile:
		butt = line.split('\t')
		bookmarks[butt[0]] = butt[1]
except (FileNotFoundError,IndexError):
	pass
# build escape codes
escapes = {}
try:
	escapefile = open('modules/escapes.tsv','r',encoding='utf-8').read().split('\n')
	for line in escapefile:
		butt = line.split('\t')
		escapes[butt[0]] = butt[1]
except (FileNotFoundError,IndexError):
	pass

# history
history = []
past = []
future = []

# MAKE SURE TO USE [^\0] instead of .!!!!!

def getdomain(url):
	''' get domain url'''
	return re.search(r'^https?:\/.+?(?=\/)',url,flags=re.IGNORECASE).group(0)

def getpagefolder(url):
	''' get everything but the page (ie. domain + directory)'''
	return re.search(r'^https?:\/.+\/',url,flags=re.IGNORECASE).group(0)

def getparentfolder(url):
	''' get parent of url'''
	return re.search(r'^https?:\/.+(?=\/)',url,flags=re.IGNORECASE).group(0)

def bookmark(name,url):
	try:
		progdictfile = open(bookmarkfile,'a').write('\n'+name+'\t'+url)
	except FileNotFoundError:
		progdictfile = open(bookmarkfile,'w+').write(name+'\t'+url)
	bookmarks[name] = url

def deleteinvis(x):
	# comments
	x = re.sub('<!--[^\0]*?-->','',x)
	# head
	x = re.sub(r'<head>[^\0]*?<\/head>','',x,flags=re.IGNORECASE)
	# head stuff
	x = re.sub(r'<!DOCTYPE.+?>','',x,flags=re.IGNORECASE)
	x = re.sub(r'<(link|meta|title)[^\0]*?>','',x,flags=re.IGNORECASE)
	x = re.sub('<script.+?script>','',x,flags=re.IGNORECASE)
	x = re.sub('<style.+?style>','',x,flags=re.IGNORECASE)
	# br
	x = re.sub(r'<br\/?>','\n',x,flags=re.IGNORECASE)
	# text style
	x = re.sub(r'<\/?(a|abbr|b|del|div|h[1-6]|html|i|p|s|strong|u).*?>','',x,flags=re.IGNORECASE)
	return x

def getmeta(html):
	metas = re.findall(r'<meta.+?>',html,flags=re.IGNORECASE)
	metalist = []
	for meta in metas:
		try:
			ischarset = re.search(r'(?<=charset=").+?(?=")',meta,flags=re.IGNORECASE)
			if ischarset:
				metalist.append(('charset',ischarset.group(0)))
			else:
				name = re.search(r'(?<=name=").+?(?=")',meta,flags=re.IGNORECASE).group(0)
				content = re.search(r'(?<=content=").+?(?=")',meta,flags=re.IGNORECASE).group(0)
				metalist.append((name,content))
		except:
			pass
	return metalist

def gethreffroma(a):
	return re.search(r'(?<=href=")[^\0]*?(?=")',a,flags=re.IGNORECASE).group(0)

def gettextfroma(a):
	return re.search(r'(?<=[^a]>)[^\0]*?(?=</a>)',a,flags=re.IGNORECASE).group(0)

def getaltfromimg(img):
	try:
		return re.search(r'(?<=alt=").+?(?=")',img,flags=re.IGNORECASE).group(0)
	except AttributeError:
		return '(Image with no alt)'

def getsrcfromimg(img):
	return re.search(r'(?<=src=")[^\0]*?(?=")',img,flags=re.IGNORECASE).group(0)

def structure(html):
	headers = re.findall(r'<h[1-6].*?<\/h[1-6]>',html,flags=re.IGNORECASE)
	for header in headers:
		headertype = int(header[2])-1
		print('\t'*headertype+deleteinvis(header))
	return headers

def getlinks(x):
	links = re.findall(r'<a [^\0]*?a>',x,flags=re.IGNORECASE)
	try:
		linklist = list(zip(map(gettextfroma,links),map(gethreffroma,links)))
	except AttributeError:
		print('No links found.')
		return []
	for i in range(len(linklist)):
		link = linklist[i]
		text = link[0]
		if '<img' in link[0]: # get alts from img tags
			text = getaltfromimg(link[0])
		text = re.sub('<.+?>','',text) # remove all tags
		text = text.replace('\n','') # remove newlines
		print('('+str(i)+') '+text+'\n\t-> '+link[1]+'\n')
	return linklist

def getimg(x):
	links = re.findall(r'<img [^\0]*?>',x,flags=re.IGNORECASE)
	try:
		linklist = list(zip(map(getaltfromimg,links),map(getsrcfromimg,links)))
	except AttributeError:
		print('No images found.')
		return []
	for i in range(len(linklist)):
		link = linklist[i]
		text = link[0]
		text = text.replace('\n','') # remove newlines
		print('('+str(i)+') '+text+'\n\t-> '+link[1]+'\n')
	return linklist

def htmltotext(x):
	x = deleteinvis(x) # delete tags which will do NOTHING only
	x = x.replace('<','\n<') # clarity
	# lists style
	x = re.sub(r'<li.*?>','\t* ',x,flags=re.IGNORECASE)
	x = re.sub(r'<\/li.*?>','',x,flags=re.IGNORECASE)
	# escape codes Note: https://en.wikipedia.org/wiki/Code_page_437
	if '&' in x:
		for code in escapes:
			x = x.replace('&'+code+';',escapes[code])
	return x

def download(name,to):
	if not os.path.exists(downloads):
		os.makedirs(downloads)
	urllib.request.urlretrieve(name,filename=downloads+to)

def main():
	global location # idk if this is necessary but just in case
	html = ''
	meta = []
	linklink = []
	print(version+' loaded.')
	while 1:
		command = input('@k> ')
		action = command.split(' ')[0].lower()
		args = command.split(' ')[1:]
		unaction = ' '.join(args)
		# preformat
		if action == 'home':
			action = 'go'
			unaction = home
		elif action == 'gobook':
			action = 'go'
			unaction = bookmarks[unaction.lower()]
		elif action in ('gl','golink'):
			action = 'go'
			try:
				unaction = linklink[int(unaction)][1]
			except IndexError:
				print('Not in link range - did you forget to generate links with "link"?')
				action = 'help'
		# commands
		if action in ('about','info'):
			print(version)
			print('A text-based explorer for the interwebs.')
		elif action in ('b','bookmark'):
			bookmark(args[0].lower(),' '.join(args[1:]))
		elif action in ('bl','bookmarklist','bookmarks'):
			try:
				for line in open(bookmarkfile,'r').read().split('\n'):
					print(line)
			except:
				print('No bookmarks')
		elif action[:4] == 'disp':
			print(text)
		elif action in ('dl','download'):
			download(args[0],args[1])
		elif action in ('back','forward','gb','gf','go'):
			# detect relative versus absolute links
			try:
				if action in ('back','gb'):
					unaction = past.pop()
				elif action in ('forward','gf'):
						unaction = future.pop()
				elif unaction[:4] != 'http':
					if unaction[:3] == '../': # trying to make this work for ../blah.html
						targetparent = getpagefolder(location)
						unaction = getparentfolder(targetparent[:-1]) + unaction[3:]
					else:
						unaction = getpagefolder(location) + '/' + unaction
			except IndexError:
				unaction = location
			try:
				download(unaction,tempfile)
				html = open(downloads+tempfile).read()
				html = re.sub('[^ -~]','',html)
				meta = getmeta(html)
				text = htmltotext(html)
				# history
				if action in ('back','gb'):
					future.append(location)
				elif action in ('forward','gf'):
					past.append(location)
				else:
					history.append(unaction)
					past.append(location)
				# final
				location = unaction
			except Exception as e:
				print('problem travelling to '+unaction+' :\n'+str(e))
		elif action[:4] == 'help':
			print('about=info b=bookmark back=gb bl disp dl=download forward=gf gl=golink go gobook help hist=history image=img link meta sav source=src struct exit')
		elif action in ('hist','history'):
			for page in history:
				print(page)
		elif action in ('image','images','img'):
			images = getimg(html)
		elif action[:4] == 'link':
			linklink = getlinks(html)
		elif action[:4] == 'meta':
			for name,content in meta:
				print(name,'\n\t->',content)
		elif action[:3] == 'sav':
			download(location,unaction)
		elif action[:6] == 'struct':
			structure(html)
		elif action in ('source','src'):
			print(html)
		# leave these at the bottom
		elif action == 'exit':
			break
		else:
			print('unknown command')