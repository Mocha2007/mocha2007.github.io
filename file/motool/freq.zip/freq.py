from collections import defaultdict # counter
from re import sub # main

def counter(string):	
	text = string.lower() # case-insensitive
	text = sub(r'\s+', ' ', text) # remove multiple spacing
	text = sub("[^a-z '-]", '', text) # a-z only, with - and '
	text = text.split(' ') # create list
	dictionary = defaultdict(int)
	for word in text:
		dictionary[word] += 1
	del dictionary['']
	return sorted(dictionary.items(), key=lambda x: x[1], reverse=True)

# build freq
frequencies = []
try:
	frequencies = sub('\t+', '\n', open('modules/freq.tsv', 'r').read()).split('\n')
except FileNotFoundError:
	# running it by itself is another program
	mlist = counter(open(input('@freq> '), 'r', encoding='utf-8').read())
	for i, j in mlist:
		if j < 3:
			break
		print(i, '\t', j)
	input()

def getdictform(word): # try and get most forms, but will still miss words like redDest
	if word[-3:] in ('est', 'ing'):
		return word[:-3]
	if word[-2:] in ('ed', 'er', 'es'):
		return word[:-2]
	if word[-1] == 's':
		return word[:-1]
	return word

def main():
	print('Frequency loaded.')
	while 1:
		command = input('@freq> ').lower()
		command = sub(r"[^a-z '\-0-9]", '', command)
		action = command.split(' ')[0]
		args = command.split(' ')[1:]
		# main
		if action[:2] in ('in', 'ex'):
			try:
				n = int(args[0])
				text = args[1:]
				if 0 < n <= 2000:
					if action[:2] == 'ex':
						remainder = set(filter(lambda x: x not in frequencies[:n], text))
						if remainder:
							remainder = set(filter(lambda x: getdictform(x) not in frequencies[:n], remainder))
					else: # in
						remainder = set(filter(lambda x: (x in frequencies[:n]) or (getdictform(x) in frequencies[:n]), text))
					print(' '.join(sorted(remainder)))
				else:
					raise ValueError()
			except (IndexError, ValueError):
				print('invalid number "' + args[0] + '"')
		# leave these at the bottom
		elif action == 'help':
			print('ex=exclude in=include help info exit')
		elif action == 'info':
			print('example:\n\tex 10 how are you doing today')
			print('word list contains 2000 most common words; thus, n can be between 1 and 2000 inclusive')
		elif action == 'exit':
			break
		else:
			print('unknown command')