import re # main

# build freq
frequencies = open('modules/freq.tsv','r').read().split('\n')

def main():
	print('Frequency loaded.')
	while 1:
		command = input('@freq> ').lower()
		command = re.sub(r"[^a-z '\-0-9]",'',command)
		action = command.split(' ')[0]
		args = command.split(' ')[1:]
		try:
			n = int(args[0])
			text = args[1:]
		except (IndexError,ValueError):
			n = None
		isvalid = n and 0 < n <= 2000
		# main
		if action[:2] == 'ex':
			if isvalid:
				print(' '.join(sorted(set(filter(lambda x:x not in frequencies[:n],text)))))
			else:
				print('invalid number "'+str(n)+'"')
		elif action[:2] == 'in':
			if isvalid:
				print(' '.join(sorted(set(filter(lambda x:x in frequencies[:n],text)))))
			else:
				print('invalid number "'+str(n)+'"')
		# leave these at the bottom
		elif action == 'help':
			print('ex=exclude in=include help info exit')
		elif action == 'info':
			print('example:\n\tex 10 how are you doing today\nwordlist contains 2000 most common words; thus, n can be between 1 and 2000 inclusive')
		elif action == 'exit':
			break
		else:
			print('unknown command')