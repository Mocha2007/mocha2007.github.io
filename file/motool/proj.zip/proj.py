from math import sin, cos # proj
from math import pi # main/calc

g = 9.80665 # m/s^2
air = 1.293 # kg/m^3
bad = IndexError, ValueError

def quad(a: float, b: float, c: float) -> (float, float):
	d = b**2-4*a*c
	return (-b-d**.5)/2/a, (-b+d**.5)/2/a

def drag(rho: float, v: float, a: float, c_d: float) -> float:
	return .5*rho*v**2*c_d*a

def proj(v: float, theta: float, alt: float) -> dict:
	v_h = cos(theta)*v
	v_v = sin(theta)*v
	time = quad(-g/2, v_v, alt)[0]
	distance = v_h*time
	height_x = v_v/g # where (x) the maximum occurs
	height = -g/2*height_x**2 + v_v*height_x + alt
	result = {
		't': time,
		'd': distance,
		'v_h': v_h,
		'h': height,
	}
	return result

def sim(v: float, theta: float, alt: float) -> dict:
	resolution = 10000
	v_h = cos(theta)*v
	v_v = sin(theta)*v
	tu = proj(v, theta, alt)['t']/resolution
	# time to sim
	t = 0
	x = 0
	y = alt
	# assumes lead sphere
	r = 1
	mass = 11340 * 4/3*pi*r**3
	ys = []
	for i in range(resolution):
		# timestep
		t += tu
		# movement
		x += v_h*tu
		y += v_v*tu
		# gravity
		v_v -= g*tu
		# drag - assumes lead sphere
		force_h = drag(air, v_h, pi*r**2, .9)
		force_v = drag(air, v_v, pi*r**2, .9)
		v_h -= force_h/mass * tu
		v_v -= force_v/mass * tu
		# end test + height log
		if y < 0:
			break
		ys.append(y)
	result = {
		't': t,
		'd': x,
		'v_h': v_h,
		'h': max(ys),
	}
	return result

def main():
	print('Projectile loaded.')
	while 1:
		command = input('@proj> ')
		action = command.split(' ')[0]
		args = command.split(' ')[1:]
		# main
		if action in ('calc', 'sim'):
			# arg 1
			try:
				x_1 = float(args[0])
			except bad:
				x_1 = 1
				print('calc/sim v theta alt, eg.:\n\tcalc/sim 1 .79 0')
			# arg 2
			try:
				x_2 = float(args[1])
			except bad:
				x_2 = pi/4
			# arg 3
			try:
				x_3 = float(args[2])
			except bad:
				x_3 = 0
			if action == 'calc':
				temp = proj(x_1, x_2, x_3)
			else: # if action == 'sim':
				temp = sim(x_1, x_2, x_3)
			# display
			for i in sorted(temp.keys()):
				print(i, '\t', temp[i])
		# leave these at the bottom
		elif action == 'help':
			print('calc sim help exit')
		elif action == 'exit':
			break
		else:
			print('unknown command')