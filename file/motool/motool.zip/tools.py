import os,subprocess,urllib.request,zipfile,sys

filename = os.path.dirname(os.path.abspath(__file__))

user_agent = 'Motool/1.0'
headers={'User-Agent':user_agent,}

currentfolder = os.path.abspath(os.path.dirname(__file__))

online = 'https://mocha2007.github.io/file/motool/'
onlinelistfile = online+'files.txt'

helpdox = {
	'about':'about motool\n\tabout',
	'cd':'change directory\n\tcd C:/',
	'dir':'lists files in a directory\n\tdir C:/',
	'eval':'evaluate python\n\teval 1+1',
	'exit':'exit motool\n\texit',
	'mode':'change display mode\n\tmode @m',
	'help':'>:U\n\thelp help',
	'packman':'run the package manager\n\tpackman',
	'restart':'restart motool\n\trestart',
	'run':'runs program\n\trun notepad C:/Windows/ntbtlog.txt', # args not working rn for some reason
	'size':'get size of directory\n\size C:/Windows/',
}

progdict = {}
try:
	progdictfile = open('progdict.tsv','r').read().split('\n')
	for line in progdictfile:
		butt = line.split('\t')
		progdict[butt[0]] = butt[1]
except FileNotFoundError:
	open('progdict.tsv','w+').write('')

# https://stackoverflow.com/a/1392549/2579798
def get_size(start_path = '.'):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(start_path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            total_size += os.path.getsize(fp)
    return total_size

def specialize(arg,*args):
	try:
		forbidden = args[0]
	except IndexError:
		forbidden = ''
	if '@' in arg and '@' not in forbidden:
		return arg.replace('@',working)
	return arg

def packman():
	# try to update
	try:
		urllib.request.urlretrieve(onlinelistfile,filename=currentfolder+"\\files.txt")
	except:
		print('could not update list!\nattempting to retrieve predownloaded list...')
	# show
	filelist = open(currentfolder+"\\files.txt",'r').read()
	print(filelist)
	# work
	while 1:
		command = input('@packman> ')
		action = command.split(' ')[0].lower()
		unaction = ' '.join(command.split(' ')[1:])
		# dl download
		if action == 'dl':
			urllib.request.urlretrieve(online+unaction,filename=currentfolder+"\\"+unaction)
		# uz unzip, ie. install
		elif action == 'uz':
			# unzip
			with zipfile.ZipFile(unaction+'.zip', 'r') as zip_ref:
				zip_ref.extractall(currentfolder)
			# 'install'
			try:
				open('modules.tsv','a').write('\n'+unaction)
			except FileNotFoundError:
				open('modules.tsv','w+').write(unaction)
		elif action == 'exit':
			break
		else: # help
			print('dl exit help uz')

def main(command):
	global mode
	global working
	action = command.split(' ')[0].lower()
	args = command.split(' ')[1:]
	unaction = ' '.join(args)
	if action == 'about':
		print(open('about.txt','r').read())
	elif action == 'cd':
		working = specialize(unaction)
		if mode[1] == ':':
			mode = working
	elif action == 'dir':
		for i in os.listdir(specialize(working)):
			print(i)
	elif action == 'eval':
		print(eval(unaction))
	elif action == 'help':
		try:
			print(helpdox[args[0]])
		except IndexError:
			print(' '.join(sorted(list(helpdox))))
	elif action == 'mode':
		if unaction == '@m':
			mode = '@m'
		else:
			if mode == '@m':
				mode = working
			else:
				mode = '@m'
	elif action == 'packman':
		packman()
	elif action == 'run':
		try:
			attempt = [progdict[args[0]],args[1]]
		except IndexError:
			attempt = [progdict[unaction]]
		except KeyError:
			attempt = [specialize(unaction)]
		subprocess.call(attempt)
	elif action == 'size':
		print(get_size(specialize(unaction)))
	# keep this last
	elif action in ('exit','restart'):
		if action == 'restart':
			os.startfile('tools.py')
		sys.exit()

working = filename
mode = '@m'
while 1:
	try:
		problem = main(input(mode+'> '))
	except Exception as e:
		print(e)