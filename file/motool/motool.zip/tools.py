import os,subprocess,urllib.request,zipfile,sys,importlib.util

filename = os.path.dirname(os.path.abspath(__file__))

user_agent = 'Motool/1.0'
headers={'User-Agent':user_agent,}

currentfolder = os.path.abspath(os.path.dirname(__file__))

online = 'https://mocha2007.github.io/file/motool/'
onlinelistfile = online+'files.txt'

helpdox = {
	'about':'about motool\n\tabout',
	'cd':'change directory\n\tcd C:/',
	'dir':'lists files in a directory\n\tdir C:/',
	'eval':'evaluate python\n\teval 1+1',
	'exit':'exit motool\n\texit',
	'mode':'change display mode\n\tmode @m',
	'help':'>:U\n\thelp help',
	'packman':'run the package manager\n\tpackman',
	'read':'read file\n\t read about.txt',
	'restart':'restart motool\n\trestart',
	'run':'runs program\n\trun notepad C:/Windows/ntbtlog.txt', # args not working rn for some reason
	'size':'get size of directory\n\size C:/Windows/',
}

progdict = {}
try:
	progdictfile = open('data/progdict.tsv','r').read().split('\n')
	for line in progdictfile:
		butt = line.split('\t')
		progdict[butt[0]] = butt[1]
except FileNotFoundError:
	open('data/progdict.tsv','w+').write('')

# https://stackoverflow.com/a/1392549/2579798
def get_size(start_path = '.'):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(start_path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            total_size += os.path.getsize(fp)
    return total_size

def specialize(arg,*args):
	try:
		forbidden = args[0]
	except IndexError:
		forbidden = ''
	if '@' in arg and '@' not in forbidden:
		return arg.replace('@',working)
	return arg

def packman():
	# try to update
	try:
		urllib.request.urlretrieve(onlinelistfile,filename=currentfolder+'/data/files.txt')
	except:
		print('could not update list!\nattempting to retrieve predownloaded list...')
	# show
	filelist = open(currentfolder+'/data/files.txt','r').read()
	print(filelist)
	# work
	while 1:
		command = input('@packman> ')
		action = command.split(' ')[0].lower()
		unaction = ' '.join(command.split(' ')[1:])
		# dl download
		if action == 'dl':
			urllib.request.urlretrieve(online+unaction,filename=currentfolder+'/'+unaction)
		# refresh
		elif action == 'refresh':
			try:
				urllib.request.urlretrieve(onlinelistfile,filename=currentfolder+'/data/files.txt')
			except:
				print('could not update list!')
			print(filelist)
		# uz unzip, ie. install
		elif action == 'uz':
			# unzip
			with zipfile.ZipFile(unaction+'.zip', 'r') as zip_ref:
				zip_ref.extractall(currentfolder+'/modules')
			# 'install'
			try:
				open('data/modules.tsv','a').write('\n'+unaction)
			except FileNotFoundError:
				open('data/modules.tsv','w+').write(unaction)
		elif action == 'exit':
			break
		else: # help
			print('dl exit help refresh uz')

def main(command):
	global mode
	global working
	action = command.split(' ')[0].lower()
	args = command.split(' ')[1:]
	unaction = ' '.join(args)
	if action == 'about':
		print(open('about.txt','r').read())
	elif action == 'cd':
		desire = specialize(unaction)
		if desire[1] == ':':
			working = specialize(unaction)
		else:
			working += '/'+specialize(unaction)
		if mode[1] == ':':
			mode = working
	elif action == 'dir':
		for i in os.listdir(specialize(working)):
			print(i)
	elif action == 'eval':
		print(eval(unaction))
	elif action == 'help':
		try:
			print(helpdox[args[0]])
		except IndexError:
			print(' '.join(sorted(list(helpdox))))
		try:
			packs = open('data/modules.tsv','r').read()
			print('~'*60+'\npackages:\n'+'~'*60+'\n'+packs)
		except FileNotFoundError:
			pass
	elif action == 'mode':
		if unaction == '@m':
			mode = '@m'
		else:
			if mode == '@m':
				mode = working
			else:
				mode = '@m'
	elif action == 'packman':
		packman()
	elif action == 'read':
		print(open(working+'/'+unaction,'r').read())
	elif action == 'run':
		try:
			attempt = [progdict[args[0]],args[1]]
		except IndexError:
			attempt = [progdict[unaction]]
		except KeyError:
			attempt = [specialize(unaction)]
		subprocess.call(attempt)
	elif action == 'size':
		if command.lower() == 'size':
			print(get_size(working))
		else:
			print(get_size(specialize(unaction)))
	# keep this last
	elif action in ('exit','restart'):
		if action == 'restart':
			os.startfile('tools.py')
		sys.exit()
	# maybe it's another module...?
	else:
		try:
			spec = importlib.util.spec_from_file_location(action,'modules/'+action+'.py')
			foo = importlib.util.module_from_spec(spec)
			spec.loader.exec_module(foo)
			foo.main()
		except FileNotFoundError:
			print('no such command or module')

working = filename
mode = '@m'
while 1:
	try:
		problem = main(input(mode+'> '))
	except Error as e:
		print(e)