import os # everywhere
import sys # exit + restart + sys
import subprocess # run
import platform, zipfile # packman
import urllib.request, urllib.error # download, packman
import importlib.util # module running

version = 'Motool/1.2'

systeminfo = platform.platform().replace('-', ' ')
user_agent = version+' ('+systeminfo+' mocha2007.github.io)'
headers = {'User-Agent': user_agent}

currentfolder = os.path.abspath(os.path.dirname(__file__))

# settings
cfg = 'data/settings.json'
try:
	settings = eval(open(cfg, 'r').read())
except FileNotFoundError:
	settings = {}

try:
	online = settings['servers']
except KeyError:
	online = ['https://mocha2007.github.io/file/motool/']

onlinelistfile = 'files.txt'

helpdox = {
	'about': 'about motool\n\tabout',
	'cd': 'change directory\n\tcd C:/',
	'dir': 'lists files in a directory\n\tdir C:/',
	'eval': 'evaluate python\n\teval 1+1',
	'exit': 'exit motool\n\texit',
	'mode': 'change display mode\n\tmode @m',
	'help': '>:U\n\thelp help',
	'packman': 'run the package manager\n\tpackman',
	'read': 'read file\n\t read about.txt',
	'restart': 'restart motool\n\trestart',
	'run': 'runs program\n\trun notepad C:/Windows/ntbtlog.txt',
	'size': 'get size of directory\n\tsize C:/Windows/',
	'sys': 'system info\n\tsys',
}

if not os.path.exists(currentfolder+'/data'):
	os.makedirs(currentfolder+'/data')
# program dictionary
progdict = {}
try:
	progdictfile = open(currentfolder+'/data/progdict.tsv', 'r').read().split('\n')
	for line in progdictfile:
		butt = line.split('\t')
		progdict[butt[0]] = butt[1]
except (FileNotFoundError, IndexError):
	pass
# modules
try:
	modules = open(currentfolder+'/data/modules.tsv', 'r').read().split('\n')
except FileNotFoundError:
	modules = []

def addmod(name: str):
	global modules
	modules = list(set(modules+[name]))
	open(currentfolder+'/data/modules.tsv', 'w+').write('\n'.join(modules))

# https://stackoverflow.com/a/1392549/2579798
def get_size(start_path: str='.') -> int:
	total_size = 0
	for dirpath, dirnames, filenames in os.walk(start_path):
		for f in filenames:
			fp = os.path.join(dirpath, f)
			total_size += os.path.getsize(fp)
	return total_size

def specialize(arg: str, *args) -> str:
	try:
		forbidden = args[0]
	except IndexError:
		forbidden = ''
	if '@' in arg and '@' not in forbidden:
		return arg.replace('@', working)
	return arg

# https://stackoverflow.com/a/17317468/2579798
def start_file(n: str):
	if sys.platform == "win32":
		os.startfile(n)
	else:
		opener = "open" if sys.platform == "darwin" else "xdg-open"
		subprocess.call([opener, n])

def restart():
	start_file(currentfolder+'/tools.py')
	sys.exit()

def refresh_cfg():
	open(cfg, 'w+').write(str(settings))

def download(name: str, to: str):
	if not os.path.exists(currentfolder+'/downloads'):
		os.makedirs(currentfolder+'/downloads')
	urllib.request.urlretrieve(name, filename=currentfolder+'/downloads/'+to)

def packman():
	# try to update
	bestserver = ''
	for server in online:
		try:
			urllib.request.urlretrieve(server+onlinelistfile, filename=currentfolder+'/data/files.txt')
			bestserver = server
			break
		except urllib.error.HTTPError:
			print('could not connect to', server)
	
	if bestserver == '':
		print('could not update list!\nattempting to retrieve predownloaded list...')
	# show
	try:
		filelist = open(currentfolder+'/data/files.txt', 'r').read()
		print(filelist)
	except FileNotFoundError:
		print('no predownloaded list!')
	# work
	while 1:
		command = input('@p> ')
		action = command.split(' ')[0].lower()
		unaction = ' '.join(command.split(' ')[1:])
		# add server
		if action in ('a', 'add'):
			settings['servers'].append(unaction)
			refresh_cfg()
		# dl download
		elif action in ('d', 'dl', 'download'):
			try:
				download(bestserver+unaction, unaction)
			except urllib.error.HTTPError:
				try:
					download(bestserver+unaction+'.zip', unaction+'.zip')
				except urllib.error.HTTPError:
					print(unaction+' not found')
		# fully download + install a module
		elif action in ('i', 'install'):
			try:
				download(bestserver+unaction+'.zip', unaction+'.zip')
			except urllib.error.HTTPError:
				print(unaction+' not found')
			if not os.path.exists(currentfolder+'/modules'):
				os.makedirs(currentfolder+'/modules')
			# unzip
			with zipfile.ZipFile(currentfolder+'/downloads/'+unaction+'.zip', 'r') as zip_ref:
				zip_ref.extractall(currentfolder+'/modules')
			# 'install'
			addmod(unaction)
		# refresh
		elif action in ('r', 'refresh'):
			try:
				urllib.request.urlretrieve(server+onlinelistfile, filename=currentfolder+'/data/files.txt')
				filelist = open(currentfolder+'/data/files.txt', 'r').read()
			except urllib.error.HTTPError:
				print('could not update list!')
			print(filelist)
		# fully update motool
		elif action in ('u', 'update'):
			download(bestserver+'motool.zip', 'motool.zip')
			# unzip
			with zipfile.ZipFile(currentfolder+'/downloads/motool.zip', 'r') as zip_ref:
				zip_ref.extractall(currentfolder)
			# restart
			restart()
		# uz unzip, ie. install
		elif action in ('uz', 'unzip'):
			if not os.path.exists('/modules'):
				os.makedirs(currentfolder+'/modules')
			# unzip
			with zipfile.ZipFile(currentfolder+'/downloads/'+unaction+'.zip', 'r') as zip_ref:
				zip_ref.extractall(currentfolder+'/modules')
			# 'install'
			addmod(unaction)
		elif action in ('e', 'exit'):
			break
		else: # help
			print('a=add d=dl=download e=exit h=help i=install r=refresh u=update uz=unzip')

def main(command: str):
	global mode
	global working
	action = command.split(' ')[0].lower()
	args = command.split(' ')[1:]
	unaction = ' '.join(args)
	if action == 'about':
		print(open(currentfolder+'/about.txt', 'r').read())
	elif action == 'cd':
		desire = specialize(unaction)
		if desire[1] == ':':
			working = specialize(unaction)
		else:
			working += '/'+specialize(unaction)
		if mode[1] == ':':
			mode = working
	elif action == 'dir':
		for i in os.listdir(specialize(working)):
			print(i)
	elif action == 'eval':
		print(eval(unaction))
	elif action == 'help':
		try:
			print(helpdox[args[0]])
		except IndexError:
			print(' '.join(sorted(list(helpdox))))
		if not unaction and modules:
			print('~'*60+'\npackages:\n'+'~'*60+'\n'+' '.join(modules))
	elif action == 'mode':
		if unaction == '@m':
			mode = '@m'
		else:
			if mode == '@m':
				mode = working
			else:
				mode = '@m'
	elif action == 'packman':
		packman()
	elif action == 'read':
		print(open(working+'/'+unaction, 'r').read())
	elif action == 'run':
		try:
			runarg = ' '.join(args[1:])
		except KeyError:
			runarg = ''
		try:
			program = progdict[args[0]]
		except KeyError:
			program = args[0]
		subprocess.call([program, runarg])
	elif action == 'size':
		if command.lower() == 'size':
			print(get_size(working))
		else:
			print(get_size(specialize(unaction)))
	elif action == 'sys':
		print(version)
		print(systeminfo)
		print('Python', sys.version)
	# keep this last
	elif action in ('exit', 'restart'):
		if action == 'restart':
			restart()
		sys.exit()
	# maybe it's another module...?
	else:
		try:
			spec = importlib.util.spec_from_file_location(action, 'modules/'+action+'.py')
			foo = importlib.util.module_from_spec(spec)
			spec.loader.exec_module(foo)
			foo.main()
		except FileNotFoundError:
			print('no such command or module')

working = currentfolder
mode = '@m'
print(version)
while 1:
	try:
		main(input(mode+'> '))
	except Exception as e: # Exception ZeroDivisionError debug
		print(e)