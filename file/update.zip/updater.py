import os,urllib.request,zipfile
from shutil import rmtree as deletefolder
from shutil import copyfile

user_agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:40.0) Gecko/20100101 Firefox/40.1'
headers={'User-Agent':user_agent,}

currentfolder = os.path.abspath(os.path.dirname(__file__))
desiredfolder = os.getenv('APPDATA')+'\\mocha'# %AppData%/mocha

versionfile = 'https://mocha2007.github.io/file/update.txt'
onlinezipfile = 'https://mocha2007.github.io/file/update.zip'

localversionfile = 'version.txt'

def readfile(loc):
	try:
		with open(localversionfile) as localfile:
			return localfile.read()
	except IOError:
		return True

def returnsite(url):
	request=urllib.request.Request(url,None,headers)
	try:
		return urllib.request.urlopen(request).read().decode("utf-8")
	except:
		return True

def returnfile(url):
	request=urllib.request.Request(url,None,headers)
	try:
		return urllib.request.urlopen(request).read()
	except:
		return True

def urlexists(url):
    if returnsite(url)==False:return False
    return True

if currentfolder==desiredfolder:
	print('resetting temp')
	deletefolder(currentfolder+'\\temp')
	#either way, remake it
	try:
		os.makedirs(currentfolder+'\\temp')
	except FileExistsError:
		pass
	#Now check for update
	if urlexists(versionfile):
		versionname = returnsite(versionfile)
		localversionname = readfile(localversionfile)
		print(localversionname,'to',versionname)
		if localversionname!=versionname:
			#update
			try:
				urllib.request.urlretrieve(onlinezipfile,filename=currentfolder+"temp\\update.zip")
				copyfile(__file__,currentfolder+'temp\\updater.py')
				#run temp/update.py
				os.startfile(currentfolder+"temp\\updater.py")
			except urllib.error.HTTPError:
				print('Unable to download zip')
		else:
			os.startfile(currentfolder+"temp\\execute.py") #file as updated as can be, INITIATE!!!
elif currentfolder==desiredfolder+'\\temp':
	print('installing update')
	with zipfile.ZipFile('update.zip', 'r') as zip_ref:
		zip_ref.extractall(os.path.dirname(os.path.dirname(__file__)))
	#run update.py
	os.startfile(desiredfolder+"\\updater.py")
else:
	print('moving to AppData/mocha')
	try:
		copyfile(__file__,desiredfolder+'\\updater.py')
	except FileNotFoundError:
		os.makedirs(desiredfolder)
		copyfile(__file__,desiredfolder+'\\updater.py')
	#run update.py
	os.startfile(desiredfolder+"\\updater.py")